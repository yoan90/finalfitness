package com.example.gener.fit_app;

/**
 * Created by gener on 25/08/2018.
 */

public class Exe_struct {
    private String name;
    private String description;

    public Exe_struct(String name, String description) {
        this.name = name;
        this.description = description;
    }

    public String getName() {
        return name;
    }

    public String getDescription() {
        return description;
    }
}
